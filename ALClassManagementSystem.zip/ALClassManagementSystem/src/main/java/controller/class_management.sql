CREATE DATABASE class_management;
USE class_management;

CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('Admin', 'Teacher', 'Student') NOT NULL
);

CREATE TABLE students (
    student_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    nic_no VARCHAR(20) UNIQUE NOT NULL,
    registered_class ENUM('Grade 12', 'Grade 13') NOT NULL,
    parent_contact VARCHAR(15) NOT NULL,
    school VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE subjects (
    subject_id INT AUTO_INCREMENT PRIMARY KEY,
    subject_name VARCHAR(50) NOT NULL
);

CREATE TABLE teachers (
    teacher_id INT AUTO_INCREMENT PRIMARY KEY,
    teacher_name VARCHAR(100) NOT NULL,
    subject_id INT,
    FOREIGN KEY (subject_id) REFERENCES subjects(subject_id)
);

CREATE TABLE student_subjects (
    enrollment_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    subject_id INT,
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (subject_id) REFERENCES subjects(subject_id)
);


SELECT s.name AS StudentName, sub.subject_name AS Subject, t.teacher_name AS Teacher
FROM student_subjects ss
JOIN students s ON ss.student_id = s.student_id
JOIN subjects sub ON ss.subject_id = sub.subject_id
JOIN teachers t ON sub.subject_id = t.subject_id;

CREATE VIEW StudentSubjectsReport AS
SELECT students.id, students.name, students.registered_class, subjects.subject_name, subjects.teacher_name
FROM students
JOIN subjects ON students.registered_class = subjects.subject_name;

SELECT * FROM StudentSubjectsReport;


