/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
import java.sql.*;
import java.util.*;


/**
 *
 * @author WEDANDA
 */
public class TimetableGenerator {
    private static final String[] DAYS = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday"};
    private static final String[] TIME_SLOTS = {"08:00 - 10:00", "10:30 - 12:30", "13:30 - 15:30"};

    public static void generateTimetable() {
        try (Connection conn = DBConnection.getConnection()) {
            Statement stmt = conn.createStatement();

            // Get subjects and teachers
            ResultSet rs = stmt.executeQuery("SELECT subject_name, teacher_name FROM subjects");
            List<String[]> subjects = new ArrayList<>();
            while (rs.next()) {
                subjects.add(new String[]{rs.getString("subject_name"), rs.getString("teacher_name")});
            }

            // Get registered classes
            ResultSet classRs = stmt.executeQuery("SELECT DISTINCT registered_class FROM students");
            List<String> classes = new ArrayList<>();
            while (classRs.next()) {
                classes.add(classRs.getString("registered_class"));
            }

            // Clear existing timetable
            stmt.executeUpdate("DELETE FROM timetable");

            // Assign subjects to time slots
            Random rand = new Random();
            for (String className : classes) {
                Set<String> assignedSlots = new HashSet<>();
                for (String day : DAYS) {
                    for (String time : TIME_SLOTS) {
                        if (subjects.isEmpty()) continue;
                        
                        // Ensure no duplicate assignments per slot
                        if (assignedSlots.contains(day + time)) continue;
                        
                        String[] subject = subjects.get(rand.nextInt(subjects.size()));
                        String subjectName = subject[0];
                        String teacherName = subject[1];

                        // Avoid assigning the same teacher to multiple classes at the same time
                        PreparedStatement checkStmt = conn.prepareStatement(
                                "SELECT * FROM timetable WHERE teacher = ? AND day_of_week = ? AND time_slot = ?");
                        checkStmt.setString(1, teacherName);
                        checkStmt.setString(2, day);
                        checkStmt.setString(3, time);
                        ResultSet checkRs = checkStmt.executeQuery();

                        if (!checkRs.next()) {
                            PreparedStatement insertStmt = conn.prepareStatement(
                                    "INSERT INTO timetable (class, subject, teacher, day_of_week, time_slot) VALUES (?, ?, ?, ?, ?)");
                            insertStmt.setString(1, className);
                            insertStmt.setString(2, subjectName);
                            insertStmt.setString(3, teacherName);
                            insertStmt.setString(4, day);
                            insertStmt.setString(5, time);
                            insertStmt.executeUpdate();
                            assignedSlots.add(day + time);
                        }
                    }
                }
            }
            System.out.println("Timetable Generated Successfully!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
}
